
<?php $__env->startSection('content'); ?>

<div class="col-md-4 m-auto border mt-5 p-2 border-info">
    <h2 class="text-center text-primary">Update </h2>
    <form action="updatedata" method="get">
        <div class="mb-3">
       <label for="">Product Name</label>
       <input type="text" name="name" value="<?php echo e($pname); ?>" class="form-control">
        </div>

        <div class="mb-2">
       <label for="">Product Price</label>
       <input type="text" name="price" value="<?php echo e($pprice); ?>" class="form-control">
        </div>
        <br>
        <input type="hidden" name="id" value="<?php echo e($pid); ?>"> 
        <div class="text-center">

        <button class="btn btn-primary rounded-pill" type="submit">Update</button>
        </div>

    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\acer\CRUD\resources\views/updateview.blade.php ENDPATH**/ ?>